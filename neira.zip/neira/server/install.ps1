﻿# Нейра: установка сервера (Windows 11)
$ErrorActionPreference = "Continue"
Set-Location $PSScriptRoot

function Info($m) { Write-Host "[*] $m" -ForegroundColor Cyan }
function Ok($m)   { Write-Host "[+] $m" -ForegroundColor Green }
function Warn($m) { Write-Host "[!] $m" -ForegroundColor Yellow }
function Fail($m) {
    Write-Host "[x] $m" -ForegroundColor Red
    Read-Host "Нажми Enter, чтобы закрыть окно"
    exit 1
}
function Ask($q) {
    $a = Read-Host "$q [Y/n]"
    return ($a -eq "" -or $a -match "^(y|Y|д|Д)")
}
function Run($exe, [string[]]$argList) {
    & $exe @argList
    if ($LASTEXITCODE -ne 0) { Fail "Команда завершилась с ошибкой: $exe $($argList -join ' ')" }
}

Write-Host ""
Write-Host "=== Установка сервера Нейры ===" -ForegroundColor Cyan
Write-Host ""

# ---------------------------------------------------------------- Python
function Test-PyVersion($exe, [string[]]$prefixArgs) {
    try {
        $v = & $exe @prefixArgs -c "import sys; print('%d.%d' % sys.version_info[:2])" 2>$null
        if ($LASTEXITCODE -ne 0 -or -not $v) { return $false }
        $parts = ("$v").Trim().Split(".")
        $minor = [int]$parts[1]
        return ([int]$parts[0] -eq 3 -and $minor -ge 10 -and $minor -le 13)
    } catch { return $false }
}

$py = $null
$pyArgs = @()
if (Get-Command py -ErrorAction SilentlyContinue) {
    foreach ($v in @("3.12", "3.11", "3.10", "3.13")) {
        if (Test-PyVersion "py" @("-$v")) { $py = "py"; $pyArgs = @("-$v"); break }
    }
}
if (-not $py -and (Get-Command python -ErrorAction SilentlyContinue)) {
    if (Test-PyVersion "python" @()) { $py = "python" }
}
if (-not $py) {
    Warn "Подходящий Python (3.10-3.13) не найден."
    if ((Get-Command winget -ErrorAction SilentlyContinue) -and (Ask "Установить Python 3.12 через winget?")) {
        winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements
        Warn "Python установлен. Закрой это окно и запусти install.bat ещё раз (нужно обновить PATH)."
        Read-Host "Нажми Enter"
        exit 0
    }
    Fail "Установи Python 3.12 с python.org (отметь галочку Add python.exe to PATH) и запусти install.bat снова."
}
Ok "Python найден"

# ---------------------------------------------------------------- видеокарта
if (Get-Command nvidia-smi -ErrorAction SilentlyContinue) {
    $gpu = (& nvidia-smi --query-gpu=name --format=csv,noheader 2>$null | Select-Object -First 1)
    Ok "Видеокарта: $gpu"
} else {
    Warn "nvidia-smi не найден. Поставь драйвер NVIDIA, иначе Whisper будет работать на процессоре (медленнее)."
}

# ---------------------------------------------------------------- venv и пакеты
$venvPy = Join-Path $PSScriptRoot "venv\Scripts\python.exe"
if (-not (Test-Path $venvPy)) {
    Info "Создаю виртуальное окружение..."
    & $py @pyArgs -m venv venv
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path $venvPy)) { Fail "Не получилось создать venv." }
}
Info "Обновляю pip..."
Run $venvPy @("-m", "pip", "install", "--upgrade", "pip")
Info "Ставлю PyTorch (версия для процессора)..."
Run $venvPy @("-m", "pip", "install", "torch", "torchaudio", "--index-url", "https://download.pytorch.org/whl/cpu")
Info "Ставлю остальные зависимости..."
Run $venvPy @("-m", "pip", "install", "-r", "requirements-server.txt")
Ok "Пакеты установлены"

# Проверка, что PyTorch вообще запускается. Частая причина сбоя загрузки DLL:
# нет Microsoft Visual C++ Redistributable или процессор без AVX2 (старые CPU).
function Test-Torch {
    & $venvPy -c "import torch" 2>$null
    return ($LASTEXITCODE -eq 0)
}
if (-not (Test-Torch)) {
    Warn "PyTorch не запускается (ошибка загрузки DLL). Ставлю Microsoft Visual C++ Redistributable..."
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        winget install -e --id Microsoft.VCRedist.2015+.x64 --accept-package-agreements --accept-source-agreements
    } else {
        Start-Process "https://aka.ms/vs/17/release/vc_redist.x64.exe"
        Read-Host "Скачай и установи vc_redist.x64.exe, потом нажми Enter"
    }
}
if (-not (Test-Torch)) {
    Warn "Всё ещё не запускается. Пробую более старую версию PyTorch (на случай процессора без AVX2)..."
    & $venvPy -m pip install "numpy<2"
    & $venvPy -m pip install torch==2.2.2 torchaudio==2.2.2 --no-deps --index-url https://download.pytorch.org/whl/cpu
}
if (-not (Test-Torch)) {
    & $venvPy -c "import torch"
    Fail "PyTorch не запустился. Скопируй текст ошибки выше и пришли его мне."
}
Ok "PyTorch работает"

# ---------------------------------------------------------------- Ollama
function Find-Ollama {
    $c = Get-Command ollama -ErrorAction SilentlyContinue
    if ($c) { return $c.Source }
    $p = Join-Path $env:LOCALAPPDATA "Programs\Ollama\ollama.exe"
    if (Test-Path $p) { return $p }
    return $null
}
function Test-Ollama {
    try {
        Invoke-WebRequest -Uri "http://127.0.0.1:11434" -UseBasicParsing -TimeoutSec 2 | Out-Null
        return $true
    } catch { return $false }
}

$ollama = Find-Ollama
if (-not $ollama) {
    Warn "Ollama не найдена."
    if ((Get-Command winget -ErrorAction SilentlyContinue) -and (Ask "Установить Ollama через winget?")) {
        winget install -e --id Ollama.Ollama --accept-package-agreements --accept-source-agreements
        $ollama = Find-Ollama
    }
}
if (-not $ollama) { Fail "Установи Ollama (ollama.com/download) и запусти install.bat снова." }

if (-not (Test-Ollama)) {
    Info "Запускаю Ollama..."
    Start-Process -FilePath $ollama -ArgumentList "serve" -WindowStyle Hidden
    for ($i = 0; $i -lt 20 -and -not (Test-Ollama); $i++) { Start-Sleep -Seconds 1 }
}
if (-not (Test-Ollama)) { Fail "Ollama не отвечает на порту 11434. Запусти её вручную и повтори установку." }
Info "Скачиваю модель-решатель qwen2.5:3b (около 2 ГБ)..."
Run $ollama @("pull", "qwen2.5:3b")
Ok "Ollama готова"

# ---------------------------------------------------------------- ключ Gemini
$envFile = Join-Path $PSScriptRoot ".env"
$haveKey = $false
if (Test-Path $envFile) {
    $haveKey = [bool](Select-String -Path $envFile -Pattern '^\s*GEMINI_API_KEY\s*=\s*\S+' -Quiet)
}
if ($haveKey) {
    Ok "Ключ Gemini уже есть в .env"
} else {
    Write-Host ""
    Write-Host "Ключ Gemini API бесплатно берётся на aistudio.google.com (кнопка Get API key)."
    $key = (Read-Host "Вставь ключ (или оставь пустым и впиши позже в файл .env)").Trim()
    if (Test-Path $envFile) {
        Add-Content -Path $envFile -Value "GEMINI_API_KEY=$key" -Encoding ASCII
    } else {
        $lines = @(
            "GEMINI_API_KEY=$key",
            "# Optional settings, uncomment to use:",
            "# INTERRUPTIONS=0",
            "# FINAL_MODEL=base",
            "# WHISPER_DEVICE=cpu",
            "# TTS_SPEAKER=xenia"
        )
        Set-Content -Path $envFile -Value $lines -Encoding ASCII
    }
    if ($key -eq "") { Warn "Ключ не введён: впиши его в файл .env после GEMINI_API_KEY=" } else { Ok "Ключ сохранён в .env" }
}

# ---------------------------------------------------------------- модели
Info "Скачиваю модели Whisper и Silero (первый раз несколько минут)..."
& $venvPy prefetch.py
if ($LASTEXITCODE -ne 0) {
    Warn "Не все модели скачались (причина выше). Установка продолжается."
    Warn "Если не скачалась модель озвучки: скачай файл вручную по ссылке из сообщения выше"
    Warn "и положи его в папку models рядом с server.py. Потом запусти install.bat ещё раз или сразу start.bat."
}

# ---------------------------------------------------------------- брандмауэр
Write-Host ""
& netsh advfirewall firewall show rule name=Neira *> $null
if ($LASTEXITCODE -eq 0) {
    Ok "Правило брандмауэра для порта 8765 уже есть"
} elseif (Ask "Открыть порт 8765 в брандмауэре Windows (чтобы клиент смог подключиться)?") {
    $rule = 'advfirewall firewall add rule name="Neira" dir=in action=allow protocol=TCP localport=8765'
    try {
        $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
        if ($isAdmin) {
            Start-Process netsh -ArgumentList $rule -Wait -NoNewWindow
        } else {
            Start-Process netsh -ArgumentList $rule -Verb RunAs -Wait
        }
        Ok "Порт 8765 открыт"
    } catch {
        Warn "Не получилось открыть порт. Сделай это вручную (PowerShell от администратора): netsh $rule"
    }
}

# ---------------------------------------------------------------- итог
$ips = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
    Where-Object { $_.IPAddress -notlike "127.*" -and $_.IPAddress -notlike "169.254.*" -and $_.InterfaceAlias -notmatch "vEthernet|Loopback|WSL" } |
    Select-Object -ExpandProperty IPAddress

Write-Host ""
Write-Host "=== Готово ===" -ForegroundColor Green
Write-Host "Запуск сервера: двойной клик по start.bat"
if ($ips) {
    Write-Host "Адрес этого ПК для клиента: $($ips -join ', ')  (порт 8765)"
} else {
    Write-Host "Адрес этого ПК смотри командой ipconfig (строка IPv4)."
}
Write-Host ""
Read-Host "Нажми Enter, чтобы закрыть окно"
