"""Загрузка модели озвучки Silero без torch.hub.

Порядок: локальный файл -> официальный сайт (models.silero.ai) -> неофициальное зеркало
на Hugging Face (только с разрешения пользователя) -> понятная инструкция "скачай вручную".
"""
import os
import time
import urllib.request

import torch
from torch.package import PackageImporter

MODEL_NAME = os.getenv("TTS_MODEL", "v4_ru")
URL = os.getenv("TTS_MODEL_URL", f"https://models.silero.ai/models/tts/ru/{MODEL_NAME}.pt")
PATH = os.getenv(
    "TTS_MODEL_PATH",
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "models", f"{MODEL_NAME}.pt"),
)
# Неофициальная копия файла v4_ru.pt (не от авторов Silero). Используется только с разрешения.
MIRROR_URL = "https://huggingface.co/Derur/silero-models/resolve/main/tts/ru/ru_v4/v4_ru.pt"
MIN_SIZE = 5_000_000  # файл меньше этого считаем битым (например, страницей с ошибкой)


def _download(url: str, attempts: int, timeout: int) -> bool:
    tmp = PATH + ".part"
    for attempt in range(1, attempts + 1):
        try:
            print(f"Скачиваю {url} (попытка {attempt}/{attempts})...", flush=True)
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=timeout) as resp, open(tmp, "wb") as out:
                while True:
                    chunk = resp.read(1 << 20)
                    if not chunk:
                        break
                    out.write(chunk)
            if os.path.getsize(tmp) < MIN_SIZE:
                raise RuntimeError("скачанный файл слишком маленький")
            os.replace(tmp, PATH)
            print("Модель озвучки скачана.", flush=True)
            return True
        except Exception as e:  # noqa: BLE001
            print(f"Не получилось: {e}", flush=True)
            time.sleep(2 * attempt)
    return False


def _mirror_allowed(allow_mirror):
    if allow_mirror is not None:
        return allow_mirror
    return os.getenv("TTS_ALLOW_MIRROR", "0") == "1"


def ensure_model(allow_mirror=None) -> str:
    """Возвращает путь к файлу модели, скачивая его при необходимости."""
    if os.path.isfile(PATH) and os.path.getsize(PATH) >= MIN_SIZE:
        return PATH

    os.makedirs(os.path.dirname(PATH), exist_ok=True)
    if _download(URL, attempts=2, timeout=20):
        return PATH

    mirror_possible = MODEL_NAME == "v4_ru" and "TTS_MODEL_URL" not in os.environ
    if mirror_possible and _mirror_allowed(allow_mirror):
        if _download(MIRROR_URL, attempts=3, timeout=30):
            return PATH

    hint = f"\n  или с неофициального зеркала:\n  {MIRROR_URL}" if mirror_possible else ""
    raise RuntimeError(
        "Не удалось скачать модель озвучки.\n"
        "Скачай файл вручную браузером (при необходимости через VPN):\n"
        f"  {URL}{hint}\n"
        "и положи его сюда:\n"
        f"  {PATH}"
    )


def load():
    path = ensure_model()
    model = PackageImporter(path).load_pickle("tts_models", "model")
    model.to("cpu")
    return model
