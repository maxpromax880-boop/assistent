﻿# Нейра: запуск сервера
Set-Location $PSScriptRoot

$venvPy = Join-Path $PSScriptRoot "venv\Scripts\python.exe"
if (-not (Test-Path $venvPy)) {
    Write-Host "Сначала запусти install.bat" -ForegroundColor Red
    exit 1
}

# настройки из .env (KEY=VALUE, строки с # игнорируются)
$envFile = Join-Path $PSScriptRoot ".env"
if (Test-Path $envFile) {
    foreach ($line in Get-Content $envFile) {
        if ($line -match '^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$') {
            $name = $Matches[1]
            $value = $Matches[2].Trim('"')
            if ($value -ne "") { Set-Item -Path "Env:$name" -Value $value }
        }
    }
}
if (-not $env:GEMINI_API_KEY) {
    Write-Host "Не задан GEMINI_API_KEY. Впиши ключ в файл .env (строка GEMINI_API_KEY=...)." -ForegroundColor Red
    exit 1
}

# Ollama нужна для перебиваний
function Find-Ollama {
    $c = Get-Command ollama -ErrorAction SilentlyContinue
    if ($c) { return $c.Source }
    $p = Join-Path $env:LOCALAPPDATA "Programs\Ollama\ollama.exe"
    if (Test-Path $p) { return $p }
    return $null
}
function Test-Ollama {
    try {
        Invoke-WebRequest -Uri "http://127.0.0.1:11434" -UseBasicParsing -TimeoutSec 2 | Out-Null
        return $true
    } catch { return $false }
}

if ($env:INTERRUPTIONS -ne "0" -and -not (Test-Ollama)) {
    $ollama = Find-Ollama
    if ($ollama) {
        Write-Host "Запускаю Ollama..."
        Start-Process -FilePath $ollama -ArgumentList "serve" -WindowStyle Hidden
        for ($i = 0; $i -lt 20 -and -not (Test-Ollama); $i++) { Start-Sleep -Seconds 1 }
    }
    if (-not (Test-Ollama)) {
        Write-Host "Ollama не запущена: перебивания работать не будут (остальное будет)." -ForegroundColor Yellow
    }
}

& $venvPy server.py
