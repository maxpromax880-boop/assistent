"""Скачивает все модели заранее, чтобы первый запуск сервера не ждал загрузки."""
import sys

import tts_model
from faster_whisper import WhisperModel
from silero_vad import load_silero_vad

failed = False

for name in ("tiny", "small"):
    print(f"whisper {name} ...", flush=True)
    try:
        WhisperModel(name, device="cpu", compute_type="int8")
    except Exception as e:  # noqa: BLE001
        failed = True
        print(f"Не удалось скачать whisper {name}: {e}", flush=True)

print("silero vad ...", flush=True)
load_silero_vad()

print("silero tts ...", flush=True)
try:
    tts_model.ensure_model(allow_mirror=False)
except Exception as official_error:  # noqa: BLE001
    print("\nОфициальный сайт Silero недоступен.", flush=True)
    answer = ""
    if tts_model.MODEL_NAME == "v4_ru" and sys.stdin and sys.stdin.isatty():
        print(
            "Есть неофициальная копия этого файла на Hugging Face (выложена не авторами Silero).\n"
            "Файл модели - это pickle, он выполняется при загрузке, поэтому доверять стоит только\n"
            "источнику, которому веришь. Если не хочешь, скачай файл сам (инструкция ниже).",
            flush=True,
        )
        answer = input("Скачать с неофициального зеркала? [y/N] ").strip().lower()
    if answer in ("y", "yes", "д", "да"):
        try:
            tts_model.ensure_model(allow_mirror=True)
        except Exception as e:  # noqa: BLE001
            failed = True
            print(e, flush=True)
    else:
        failed = True
        print(official_error, flush=True)

if failed:
    print("\nНе все модели скачались (см. сообщения выше).", flush=True)
    sys.exit(1)
print("OK: все модели скачаны")
