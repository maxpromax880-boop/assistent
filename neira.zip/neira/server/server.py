#!/usr/bin/env python3
"""
Нейра: серверная часть.

Клиент (Windows) шлёт по WebSocket сырое аудио с микрофона (16 кГц, моно, int16).
Сервер:
  1. ловит речь через Silero VAD,
  2. пока человек говорит, показывает черновик текста (faster-whisper tiny),
  3. по паузам может сама вклиниться с уточняющим вопросом
     (маленькая локальная модель в Ollama решает WAIT/ASK, вопрос пишет Gemini),
  4. когда человек договорил, распознаёт финальный текст (faster-whisper small),
  5. отвечает через Gemini потоком, режет ответ на предложения и озвучивает Silero,
  6. шлёт клиенту аудио (24 кГц, моно, int16).

Протокол:
  клиент -> сервер: binary = аудио; text JSON {"type":"text","text":"..."} для теста без микрофона
  сервер -> клиент: binary = аудио ответа; text JSON:
      {"type":"partial","text":...}  живой черновик
      {"type":"final","text":...}    итоговая фраза пользователя
      {"type":"ask","text":...}      уточнение, которым она перебила
      {"type":"reply","text":...}    предложение ответа
      {"type":"stop"}                клиент должен сразу очистить очередь воспроизведения
      {"type":"error","text":...}
"""
import asyncio
import collections
import json
import logging
import os
import re
import sys
import time

if os.name == "nt":
    # Windows: подключаем CUDA-библиотеки из pip-пакетов nvidia-cublas-cu12 / nvidia-cudnn-cu12
    # (это нужно сделать ДО импорта faster_whisper)
    import glob
    import site

    _bases = [os.path.join(sys.prefix, "Lib", "site-packages")]
    try:
        _bases += site.getsitepackages() + [site.getusersitepackages()]
    except Exception:
        pass
    for _base in _bases:
        for _dll_dir in glob.glob(os.path.join(_base, "nvidia", "*", "bin")):
            os.environ["PATH"] = _dll_dir + os.pathsep + os.environ.get("PATH", "")
            try:
                os.add_dll_directory(_dll_dir)
            except (OSError, AttributeError):
                pass

import httpx
import numpy as np
import torch
import websockets
from faster_whisper import WhisperModel
from google import genai
from google.genai import types
from silero_vad import load_silero_vad

import tts_model

# ----------------------------------------------------------------- настройки
HOST = os.getenv("HOST", "0.0.0.0")
PORT = int(os.getenv("PORT", "8765"))

GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-flash-lite-latest")

OLLAMA_URL = os.getenv("OLLAMA_URL", "http://127.0.0.1:11434")
DECIDER_MODEL = os.getenv("DECIDER_MODEL", "qwen2.5:3b")

WHISPER_DEVICE = os.getenv("WHISPER_DEVICE", "cuda")     # cuda или cpu
WHISPER_COMPUTE = os.getenv("WHISPER_COMPUTE", "int8")   # на GTX 1060 лучше int8
PARTIAL_MODEL = os.getenv("PARTIAL_MODEL", "tiny")
FINAL_MODEL = os.getenv("FINAL_MODEL", "small")
LANG = os.getenv("LANG_CODE", "ru")

TTS_SPEAKER = os.getenv("TTS_SPEAKER", "xenia")          # aidar, baya, kseniya, xenia, eugene
TTS_SR = 24000

INTERRUPTIONS = os.getenv("INTERRUPTIONS", "1") == "1"   # перебивать уточняющими вопросами
INTERJECT_COOLDOWN = float(os.getenv("INTERJECT_COOLDOWN", "15"))  # сек между перебиваниями
INTERJECT_MIN_SPEECH_MS = int(os.getenv("INTERJECT_MIN_SPEECH_MS", "3000"))
INTERJECT_MIN_WORDS = int(os.getenv("INTERJECT_MIN_WORDS", "8"))
INTERJECT_PER_TURN = int(os.getenv("INTERJECT_PER_TURN", "1"))

SR = 16000
WIN_SAMPLES = 512                        # окно Silero VAD для 16 кГц
WIN_BYTES = WIN_SAMPLES * 2
WIN_MS = WIN_SAMPLES * 1000 // SR        # 32 мс
VAD_THRESHOLD = float(os.getenv("VAD_THRESHOLD", "0.5"))
END_SILENCE_MS = int(os.getenv("END_SILENCE_MS", "800"))   # пауза, после которой фраза считается законченной
MICRO_PAUSE_MS = 250                     # пауза, на которой разрешено вклиниться
MIN_SPEECH_MS = 300                      # короче этого считаем шумом
PARTIAL_EVERY = float(os.getenv("PARTIAL_EVERY", "1.0"))
MAX_HISTORY = 24

PERSONA = """Ты - Нейра, дерзкая, немного хаотичная ИИ-стримерша. Ты общаешься голосом.
Правила:
- Отвечай коротко: одно-три предложения.
- Говори живо, с юмором и подколами, но по-доброму.
- Никаких списков, markdown, эмодзи и звёздочек: твой текст озвучивается.
- Числа пиши словами, английских слов избегай.
- Не выходи из образа и не объясняй, что ты языковая модель.
Примеры:
Человек: Я сегодня ничего не успел.
Нейра: Классика. Планов громадьё, результат как у кота: поспал и доволен.
Человек: Как думаешь, мне купить новую видеокарту?
Нейра: Конечно, деньги же лишние. Ладно, расскажи, под что тебе она нужна."""

DECIDER_PROMPT = """Ты слушаешь человека, который ещё говорит, и решаешь, стоит ли перебить его уточняющим вопросом.
Перебивай ТОЛЬКО если без уточнения нельзя понять суть: непонятно, о ком или о чём речь, использован неизвестный термин, есть явное противоречие.
Если есть малейшие сомнения, отвечай WAIT.
Ответ строго одно слово: WAIT или ASK.

Текст: "{text}"
Ответ:"""

HALLUCINATIONS = ("продолжение следует", "субтитры", "спасибо за просмотр", "редактор субтитров")

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("neira")
torch.set_num_threads(int(os.getenv("TORCH_THREADS", "4")))

# ----------------------------------------------------------------- модели
gemini = genai.Client(api_key=os.environ["GEMINI_API_KEY"])
CHAT_CFG = types.GenerateContentConfig(
    system_instruction=PERSONA, temperature=1.0, max_output_tokens=220
)

PARTIAL_LOCK = asyncio.Lock()
FINAL_LOCK = asyncio.Lock()
TTS_LOCK = asyncio.Lock()
HTTP: httpx.AsyncClient = None  # создаётся в main()


def load_whisper(name):
    for device, compute in ((WHISPER_DEVICE, WHISPER_COMPUTE), ("cpu", "int8")):
        try:
            model = WhisperModel(name, device=device, compute_type=compute)
            # прогрев: именно тут вылезают ошибки с отсутствующими CUDA-библиотеками
            list(model.transcribe(np.zeros(SR, dtype=np.float32), language=LANG)[0])
            log.info("whisper %s: %s/%s", name, device, compute)
            return model
        except Exception as e:
            log.warning("whisper %s на %s не запустился: %s", name, device, e)
    raise RuntimeError(f"Не удалось загрузить whisper {name}")


def load_tts():
    return tts_model.load()


WHISPER_PARTIAL = None
WHISPER_FINAL = None
TTS = None


# ----------------------------------------------------------------- утилиты
async def transcribe(model, lock, pcm: bytes, beam: int) -> str:
    audio = np.frombuffer(pcm, dtype=np.int16).astype(np.float32) / 32768.0

    def run():
        segments, _ = model.transcribe(
            audio,
            language=LANG,
            beam_size=beam,
            vad_filter=False,
            condition_on_previous_text=False,
            without_timestamps=True,
        )
        return " ".join(s.text.strip() for s in segments).strip()

    async with lock:
        return await asyncio.to_thread(run)


def clean_for_tts(text: str) -> str:
    text = re.sub(r"[^\w\s.,!?:;\-—…()«»\"']", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def synthesize(text: str):
    text = clean_for_tts(text)
    if not re.search(r"\w", text):
        return None
    try:
        wav = TTS.apply_tts(
            text=text, speaker=TTS_SPEAKER, sample_rate=TTS_SR, put_accent=True, put_yo=True
        )
    except Exception as e:
        log.warning("TTS не смог озвучить %r: %s", text, e)
        return None
    return (wav.clamp(-1, 1) * 32767).to(torch.int16).numpy().tobytes()


def split_sentences(buf: str):
    """Возвращает (готовые предложения, остаток). Слишком короткие куски склеиваются."""
    out, start = [], 0
    for m in re.finditer(r"[.!?…]+[\"»)]*\s+", buf):
        piece = buf[start:m.end()]
        if len(piece.strip()) >= 15:
            out.append(piece.strip())
            start = m.end()
    return out, buf[start:]


def trimmed_history(history):
    trimmed = list(history[-MAX_HISTORY:])
    while trimmed and trimmed[0].role != "user":
        trimmed.pop(0)
    return trimmed


async def decide(text: str) -> bool:
    """True, если маленькая модель считает, что надо перебить."""
    try:
        r = await HTTP.post(
            f"{OLLAMA_URL}/api/generate",
            json={
                "model": DECIDER_MODEL,
                "prompt": DECIDER_PROMPT.replace("{text}", text[-600:]),
                "stream": False,
                "keep_alive": "30m",
                "options": {"temperature": 0, "num_predict": 4},
            },
        )
        return r.json().get("response", "").strip().upper().startswith("ASK")
    except Exception as e:
        log.warning("решатель недоступен: %s", e)
        return False


async def make_question(text: str) -> str:
    try:
        resp = await gemini.aio.models.generate_content(
            model=GEMINI_MODEL,
            contents=(
                f'Человек ещё говорит. Вот что он сказал пока:\n"{text}"\n\n'
                "Задай ОДИН короткий уточняющий вопрос (до десяти слов). Только сам вопрос."
            ),
            config=types.GenerateContentConfig(
                system_instruction=PERSONA, temperature=0.7, max_output_tokens=60
            ),
        )
        return (resp.text or "").strip()
    except Exception as e:
        log.warning("не получилось сформулировать вопрос: %s", e)
        return ""


# ----------------------------------------------------------------- сессия
class Session:
    def __init__(self, ws):
        self.ws = ws
        self.vad = load_silero_vad()
        self.pending = bytearray()
        self.preroll = collections.deque(maxlen=10)
        self.buf = bytearray()
        self.in_speech = False
        self.speech_run = 0
        self.silence_ms = 0
        self.speech_ms = 0
        self.utt_id = 0
        self.partial_text = ""
        self.last_partial_t = 0.0
        self.partial_task = None
        self.final_tasks = set()
        self.speak_task = None
        self.interject_task = None
        self.interjections = []
        self.last_interject = 0.0
        self.checked_words = 0
        self.carry = ""
        self.history = []

    # ---- связь
    async def send_json(self, obj):
        try:
            await self.ws.send(json.dumps(obj, ensure_ascii=False))
        except websockets.ConnectionClosed:
            pass

    async def send_audio(self, pcm: bytes):
        frame = 9600  # 0.2 с
        for i in range(0, len(pcm), frame):
            await self.ws.send(pcm[i:i + frame])

    # ---- приём аудио и VAD
    async def feed(self, data: bytes):
        self.pending += data
        while len(self.pending) >= WIN_BYTES:
            win = bytes(self.pending[:WIN_BYTES])
            del self.pending[:WIN_BYTES]
            await self.process_window(win)

    async def process_window(self, win: bytes):
        audio = np.frombuffer(win, dtype=np.int16).astype(np.float32) / 32768.0
        speech = self.vad(torch.from_numpy(audio), SR).item() > VAD_THRESHOLD

        if not self.in_speech:
            self.preroll.append(win)
            if speech:
                self.speech_run += 1
                if self.speech_run >= 2:
                    await self.start_utterance()
            else:
                self.speech_run = 0
            return

        self.buf += win
        if speech:
            self.silence_ms = 0
            self.speech_ms += WIN_MS
        else:
            self.silence_ms += WIN_MS

        now = time.monotonic()
        if now - self.last_partial_t >= PARTIAL_EVERY and (
            self.partial_task is None or self.partial_task.done()
        ):
            self.last_partial_t = now
            self.partial_task = asyncio.create_task(self.do_partial(bytes(self.buf), self.utt_id))

        if self.silence_ms >= END_SILENCE_MS:
            await self.end_utterance()
        elif INTERRUPTIONS and self.silence_ms >= MICRO_PAUSE_MS:
            self.maybe_interject()

    async def start_utterance(self):
        # человек заговорил: заставляем её замолчать (и очищаем очередь на клиенте)
        await self.cancel_speech()
        self.in_speech = True
        self.utt_id += 1
        self.buf = bytearray(b"".join(self.preroll))
        self.preroll.clear()
        self.silence_ms = 0
        self.speech_ms = 0
        self.partial_text = ""
        self.checked_words = 0
        self.interjections = []

    async def end_utterance(self):
        self.in_speech = False
        self.speech_run = 0
        pcm = bytes(self.buf)
        speech_ms = self.speech_ms
        interj = list(self.interjections)
        self.buf = bytearray()
        self.preroll.clear()
        self.vad.reset_states()
        if speech_ms < MIN_SPEECH_MS:
            return
        task = asyncio.create_task(self.handle_final(pcm, interj))
        self.final_tasks.add(task)
        task.add_done_callback(self.final_tasks.discard)

    # ---- распознавание
    async def do_partial(self, pcm: bytes, utt: int):
        try:
            text = await transcribe(WHISPER_PARTIAL, PARTIAL_LOCK, pcm, beam=1)
        except Exception as e:
            log.warning("partial: %s", e)
            return
        if utt == self.utt_id and self.in_speech and text:
            self.partial_text = text
            await self.send_json({"type": "partial", "text": text})

    async def handle_final(self, pcm: bytes, interj):
        try:
            text = await transcribe(WHISPER_FINAL, FINAL_LOCK, pcm, beam=3)
        except Exception as e:
            log.warning("final: %s", e)
            await self.send_json({"type": "error", "text": f"STT: {e}"})
            return
        if not text or any(h in text.lower() for h in HALLUCINATIONS):
            return
        await self.send_json({"type": "final", "text": text})
        if self.in_speech:
            # человек уже продолжил говорить: копим и ответим на всё сразу
            self.carry = f"{self.carry} {text}".strip()
            return
        await self.user_said(f"{self.carry} {text}".strip(), interj)
        self.carry = ""

    async def user_said(self, text: str, interj=()):
        note = ""
        if interj:
            note = "\n(Пока человек говорил, ты уже вставила уточнение: " + "; ".join(interj) + ")"
        self.history.append(types.Content(role="user", parts=[types.Part(text=text + note)]))
        self.start_speaking(self.reply())

    # ---- перебивание
    def maybe_interject(self):
        if self.interject_task and not self.interject_task.done():
            return
        if self.speak_task and not self.speak_task.done():
            return
        if len(self.interjections) >= INTERJECT_PER_TURN:
            return
        if time.monotonic() - self.last_interject < INTERJECT_COOLDOWN:
            return
        if self.speech_ms < INTERJECT_MIN_SPEECH_MS:
            return
        words = len(self.partial_text.split())
        if words < INTERJECT_MIN_WORDS or words < self.checked_words + 4:
            return
        self.checked_words = words
        self.interject_task = asyncio.create_task(self.interject(self.partial_text, self.utt_id))

    async def interject(self, text: str, utt: int):
        if not await decide(text):
            return
        if utt != self.utt_id or not self.in_speech:
            return
        question = await make_question(text)
        if not question or utt != self.utt_id or not self.in_speech:
            return
        self.interjections.append(question)
        self.last_interject = time.monotonic()
        log.info("перебиваю: %s", question)
        await self.send_json({"type": "ask", "text": question})
        self.start_speaking(self.say(question))

    # ---- речь
    def start_speaking(self, coro):
        self.speak_task = asyncio.create_task(coro)

    async def cancel_speech(self):
        task = self.speak_task
        if task and not task.done():
            task.cancel()
            try:
                await task
            except BaseException:
                pass
        # сервер шлёт аудио быстрее реального времени, у клиента может быть запас в буфере
        await self.send_json({"type": "stop"})

    async def say(self, text: str):
        async with TTS_LOCK:
            pcm = await asyncio.to_thread(synthesize, text)
        if pcm:
            await self.send_audio(pcm)

    async def reply(self):
        queue: asyncio.Queue = asyncio.Queue()
        said = []

        async def produce():
            buf = ""
            try:
                stream = await gemini.aio.models.generate_content_stream(
                    model=GEMINI_MODEL,
                    contents=trimmed_history(self.history),
                    config=CHAT_CFG,
                )
                async for chunk in stream:
                    if chunk.text:
                        buf += chunk.text
                        sentences, buf = split_sentences(buf)
                        for s in sentences:
                            await queue.put(s)
                if buf.strip():
                    await queue.put(buf.strip())
            finally:
                await queue.put(None)

        producer = asyncio.create_task(produce())
        try:
            while True:
                sentence = await queue.get()
                if sentence is None:
                    break
                await self.say(sentence)
                said.append(sentence)
                await self.send_json({"type": "reply", "text": sentence})
            await producer
        except asyncio.CancelledError:
            raise
        except Exception as e:
            log.exception("ответ не получился")
            await self.send_json({"type": "error", "text": f"Gemini: {e}"})
        finally:
            producer.cancel()
            if said:
                self.history.append(
                    types.Content(role="model", parts=[types.Part(text=" ".join(said))])
                )

    async def close(self):
        for t in [self.speak_task, self.partial_task, self.interject_task, *self.final_tasks]:
            if t and not t.done():
                t.cancel()


# ----------------------------------------------------------------- сервер
async def handler(ws):
    log.info("клиент подключился: %s", ws.remote_address)
    session = Session(ws)
    try:
        async for msg in ws:
            if isinstance(msg, (bytes, bytearray)):
                await session.feed(bytes(msg))
            else:
                try:
                    obj = json.loads(msg)
                except json.JSONDecodeError:
                    continue
                if obj.get("type") == "text" and obj.get("text"):
                    await session.cancel_speech()
                    await session.user_said(obj["text"])
    except websockets.ConnectionClosed:
        pass
    finally:
        await session.close()
        log.info("клиент отключился")


async def main():
    global HTTP, WHISPER_PARTIAL, WHISPER_FINAL, TTS
    log.info("загружаю модели...")
    WHISPER_PARTIAL = await asyncio.to_thread(load_whisper, PARTIAL_MODEL)
    WHISPER_FINAL = await asyncio.to_thread(load_whisper, FINAL_MODEL)
    TTS = await asyncio.to_thread(load_tts)
    HTTP = httpx.AsyncClient(timeout=10)
    if INTERRUPTIONS:
        # прогреваем решатель, чтобы первый вызов не тормозил
        await decide("проверка связи")
    async with websockets.serve(handler, HOST, PORT, max_size=None):
        log.info("готово, слушаю %s:%s", HOST, PORT)
        await asyncio.Future()


if __name__ == "__main__":
    asyncio.run(main())
