#!/usr/bin/env python3
"""
Нейра: клиент (Linux, Windows, macOS).
Берёт звук с микрофона, шлёт на сервер, проигрывает ответ.

Запуск:
    python client.py --server ws://IP_СЕРВЕРА:8765
    python client.py --list-devices
    python client.py --server ws://... --input-device 1 --output-device 3

Лучше сидеть в наушниках, иначе микрофон услышит её голос из колонок.
Если без наушников никак: флаг --half-duplex (микрофон глушится, пока она говорит,
но тогда её нельзя перебить голосом).
"""
import argparse
import asyncio
import json
import shutil
import sys
import threading

import sounddevice as sd
import websockets

IN_RATE = 16000     # микрофон -> сервер
OUT_RATE = 24000    # сервер -> колонки
BLOCK = 1600        # 100 мс микрофона


class Player:
    """Воспроизведение через callback: буфер можно мгновенно очистить (перебивание)."""

    def __init__(self, device):
        self._buf = bytearray()
        self._lock = threading.Lock()
        self.stream = sd.RawOutputStream(
            samplerate=OUT_RATE,
            channels=1,
            dtype="int16",
            blocksize=1024,
            device=device,
            callback=self._callback,
        )

    def _callback(self, outdata, frames, time, status):
        need = frames * 2
        with self._lock:
            chunk = bytes(self._buf[:need])
            del self._buf[:need]
        outdata[:len(chunk)] = chunk
        if len(chunk) < need:
            outdata[len(chunk):] = bytes(need - len(chunk))

    def add(self, data: bytes):
        with self._lock:
            self._buf += data

    def clear(self):
        with self._lock:
            self._buf.clear()

    def busy(self) -> bool:
        with self._lock:
            return len(self._buf) > 0


def show_line(prefix: str, text: str, final: bool):
    width = shutil.get_terminal_size((100, 20)).columns - 1
    line = f"{prefix}{text}"
    if final:
        print("\r" + line.ljust(width))
    else:
        print("\r" + line[-width:].ljust(width), end="", flush=True)


async def sender(ws, mic_q: asyncio.Queue, player: Player, half_duplex: bool):
    while True:
        data = await mic_q.get()
        if half_duplex and player.busy():
            data = bytes(len(data))  # тишина вместо звука, чтобы не слышать саму себя
        await ws.send(data)


async def receiver(ws, player: Player):
    async for msg in ws:
        if isinstance(msg, (bytes, bytearray)):
            player.add(bytes(msg))
            continue
        try:
            obj = json.loads(msg)
        except json.JSONDecodeError:
            continue
        kind, text = obj.get("type"), obj.get("text", "")
        if kind == "stop":
            player.clear()
        elif kind == "partial":
            show_line("... ", text, final=False)
        elif kind == "final":
            show_line("Ты: ", text, final=True)
        elif kind == "ask":
            show_line("Нейра (перебивает): ", text, final=True)
        elif kind == "reply":
            show_line("Нейра: ", text, final=True)
        elif kind == "error":
            show_line("[ошибка сервера] ", text, final=True)


async def run(args):
    loop = asyncio.get_running_loop()
    mic_q: asyncio.Queue = asyncio.Queue(maxsize=100)
    player = Player(args.output_device)
    player.stream.start()

    def on_mic(indata, frames, time, status):
        data = bytes(indata)

        def put():
            if mic_q.full():
                mic_q.get_nowait()
            mic_q.put_nowait(data)

        loop.call_soon_threadsafe(put)

    with sd.RawInputStream(
        samplerate=IN_RATE,
        channels=1,
        dtype="int16",
        blocksize=BLOCK,
        device=args.input_device,
        callback=on_mic,
    ):
        while True:
            try:
                async with websockets.connect(args.server, max_size=None, ping_interval=20) as ws:
                    print(f"Подключено к {args.server}. Говори. Ctrl+C для выхода.")
                    player.clear()
                    while not mic_q.empty():
                        mic_q.get_nowait()
                    tasks = [
                        asyncio.create_task(sender(ws, mic_q, player, args.half_duplex)),
                        asyncio.create_task(receiver(ws, player)),
                    ]
                    done, pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
                    for t in pending:
                        t.cancel()
                    for t in done:
                        t.result()
            except (OSError, websockets.ConnectionClosed) as e:
                print(f"\nНет связи с сервером ({e}). Повтор через 2 секунды...")
                player.clear()
                await asyncio.sleep(2)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--server", default="ws://127.0.0.1:8765")
    parser.add_argument("--input-device", default=None, help="номер или часть названия микрофона")
    parser.add_argument("--output-device", default=None, help="номер или часть названия колонок")
    parser.add_argument("--half-duplex", action="store_true")
    parser.add_argument("--list-devices", action="store_true")
    args = parser.parse_args()

    if args.list_devices:
        print(sd.query_devices())
        return

    for name in ("input_device", "output_device"):
        value = getattr(args, name)
        if value is not None and value.isdigit():
            setattr(args, name, int(value))

    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")

    try:
        asyncio.run(run(args))
    except KeyboardInterrupt:
        print("\nПока!")


if __name__ == "__main__":
    main()
