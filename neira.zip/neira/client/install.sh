#!/usr/bin/env bash
# Нейра: установка клиента (Linux)
set -euo pipefail
cd "$(dirname "$0")"

say()  { printf '\033[36m[*]\033[0m %s\n' "$*"; }
ok()   { printf '\033[32m[+]\033[0m %s\n' "$*"; }
warn() { printf '\033[33m[!]\033[0m %s\n' "$*"; }
die()  { printf '\033[31m[x]\033[0m %s\n' "$*" >&2; exit 1; }

echo
echo "=== Установка клиента Нейры ==="
echo

command -v python3 >/dev/null || die "Не найден python3. Установи его через пакетный менеджер."

# ---- PortAudio (нужен для sounddevice)
if ldconfig -p 2>/dev/null | grep -q libportaudio; then
    ok "PortAudio уже установлен"
else
    say "Ставлю PortAudio (понадобится пароль sudo)..."
    if command -v pacman >/dev/null; then
        sudo pacman -S --needed --noconfirm portaudio
    elif command -v apt-get >/dev/null; then
        sudo apt-get update && sudo apt-get install -y libportaudio2
    elif command -v dnf >/dev/null; then
        sudo dnf install -y portaudio
    else
        warn "Не знаю твой пакетный менеджер. Поставь PortAudio вручную, затем запусти скрипт снова."
    fi
fi

# ---- venv и пакеты
if [ ! -x venv/bin/python ]; then
    say "Создаю виртуальное окружение..."
    python3 -m venv venv || die "Не получилось создать venv (на Debian/Ubuntu: sudo apt install python3-venv)."
fi
say "Ставлю зависимости..."
venv/bin/python -m pip install --upgrade pip
venv/bin/python -m pip install -r requirements-client.txt
ok "Пакеты установлены"

# ---- адрес сервера
if [ -f config.env ]; then
    read -rp "config.env уже есть. Заменить адрес сервера? [y/N] " answer
    case "$answer" in [yY]*) ;; *) keep=1 ;; esac
fi
if [ -z "${keep:-}" ]; then
    echo
    echo "Адрес сервера: IP Windows-ПК в вашей сети (на сервере его покажет установщик или команда ipconfig),"
    echo "либо адрес в Tailscale."
    read -rp "IP или имя сервера (можно сразу с портом или ws://...): " host
    host="${host// /}"
    [ -n "$host" ] || die "Адрес не введён."
    case "$host" in
        ws://*|wss://*) url="$host" ;;
        *:*)            url="ws://$host" ;;
        *)              url="ws://$host:8765" ;;
    esac
    printf 'SERVER_URL="%s"\n' "$url" > config.env
    ok "Адрес сохранён: $url"
fi

# ---- проверка звука
say "Проверяю звуковые устройства..."
if venv/bin/python -c "import sounddevice as sd; print(sd.query_devices())"; then
    ok "Звук работает"
else
    warn "sounddevice не смог открыть звуковую систему. Проверь, что установлен PortAudio."
fi

chmod +x run.sh 2>/dev/null || true
echo
ok "Готово. Запуск: ./run.sh"
echo "Выбрать другой микрофон или колонки: ./run.sh --input-device N --output-device N (номера из списка выше)."
echo "Лучше сидеть в наушниках."
