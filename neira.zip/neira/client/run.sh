#!/usr/bin/env bash
# Нейра: запуск клиента. Дополнительные аргументы передаются в client.py.
cd "$(dirname "$0")"
[ -f config.env ] && source config.env
exec venv/bin/python client.py --server "${SERVER_URL:-ws://127.0.0.1:8765}" "$@"
